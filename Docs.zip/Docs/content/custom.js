﻿(function($) { "use strict";
	
	/* Mobile */
	
	if( navigator.userAgent.match(/Android/i) || navigator.userAgent.match(/webOS/i) || 
		navigator.userAgent.match(/iPhone/i) || navigator.userAgent.match(/iPad/i) || 
		navigator.userAgent.match(/iPod/i) || navigator.userAgent.match(/BlackBerry/i) || 
		navigator.userAgent.match(/Windows Phone/i) ){ 
		var mobile_device = true;
	}else{ 
		var mobile_device = false;
	}
	
	/* Vars */
	
	var $window = jQuery(window);
	var is_RTL  = jQuery('body').hasClass('rtl')?true:false;
	
	/* Menu */
	
	jQuery("nav.nav ul li ul").parent("li").addClass("parent-list");
	jQuery(".parent-list").find("a:first").append(" <span class='menu-nav-arrow'><i class='icon-right-open-mini'></i></span>");
	
	jQuery("nav.nav ul a").removeAttr("title");
	jQuery("nav.nav ul ul").css({display: "none"});
	jQuery("nav.nav ul li").each(function() {	
		var sub_menu = jQuery(this).find("ul:first");
		jQuery(this).hover(function() {	
			sub_menu.stop().css({overflow:"hidden", height:"auto", display:"none", paddingTop:0}).slideDown(200, function() {
				jQuery(this).css({overflow:"visible", height:"auto"});
			});	
		},function() {	
			sub_menu.stop().slideUp(50, function() {	
				jQuery(this).css({overflow:"hidden", display:"none"});
			});
		});	
	});
	
	var nav = jQuery('.nav_menu .menu,.mobile-menu-left .menu');
	var content = jQuery('.post-articles');
	
	nav.find('a').click(function() {
		jQuery('.mobile-aside').removeClass('mobile-aside-open');
		jQuery('.discy-main-inner,.nav_menu').removeAttr("style");
		nav.find('a').parent().removeClass('current_page_item');
		jQuery(this).parent().addClass('current_page_item');
		content.children(jQuery(this).attr('href')).fadeIn().siblings('section').hide();
		setTimeout(function() {
			discy_sidebar();
		}, 500);
		return false;
	});
	
	/* Header fixed */
	
	var fixed_enabled = jQuery("#wrap").hasClass("fixed-enabled");
	if (fixed_enabled && jQuery(".header").length) {
		var hidden_header = jQuery(".hidden-header").offset().top;
		if (hidden_header < 40) {
			var aboveHeight = -20;
		}else {
			var aboveHeight = hidden_header;
		}
		$window.scroll(function(){
			if ($window.scrollTop() > aboveHeight) {
				jQuery(".header").css({"top":"0"}).addClass("fixed-nav");
			}else {
				jQuery(".header").css({"top":"auto"}).removeClass("fixed-nav");
			}
		});
	}else {
		jQuery(".header").removeClass("fixed-nav");
	}
	
	/* Header mobile */
	
	jQuery("nav.nav > ul > li").clone().appendTo('.navigation_mobile > ul');
	
	/* Nav menu */
	
	if (jQuery(".nav_menu").length) {
		jQuery(".nav_menu > ul > li > a,.nav_menu > div > ul > li > a").on("click",function () {
			var li_menu = jQuery(this).parent();
			if (li_menu.find(" > ul").length) {
				if (li_menu.hasClass("nav_menu_open")) {
					li_menu.find(" > ul").slideUp(200,function () {
						li_menu.removeClass("nav_menu_open");
					});
				}else {
					li_menu.find(" > ul").slideDown(200,function () {
						li_menu.addClass("nav_menu_open");
					});
				}
				return false;
			}
		});
	}
	
	/* Mobile aside */
	
	if (jQuery('.mobile-aside').length) {
		jQuery('.mobile-aside li.menu-item-has-children').append('<span class="mobile-arrows"><i class="icon-down-open"></i></span>');
		
		jQuery('.mobile-aside-close').on('touchstart click',function () {
			jQuery('.mobile-aside').removeClass('mobile-aside-open');
			return false;
		});
		
		jQuery('.mobile-menu-click').on('touchstart click',function () {
			jQuery('.mobile-menu-wrap').addClass('mobile-aside-open');
			return false;
		});
		
		if (jQuery('.mobile-aside ul.menu > li').length) {
			jQuery('.mobile-aside li.menu-item-has-children > a,.mobile-aside li.menu-item-has-children > .mobile-arrows').on("touchstart click",function(){
				jQuery(this).parent().find('ul:first').slideToggle(200);
				jQuery(this).parent().find('> .mobile-arrows').toggleClass('mobile-arrows-open');
				return false;
			});
		}
		
		jQuery('.mobile-aside-inner').mCustomScrollbar({axis:'y'});
	}
	
	/* Go up */
	
	$window.scroll(function () {
		if(jQuery(this).scrollTop() > 100 ) {
			jQuery(".go-up").css("right","20px");
		}else {
			jQuery(".go-up").css("right","-60px");
		}
	});
	jQuery(".go-up").on("click",function(){
		jQuery("html,body").animate({scrollTop:0},500);
		return false;
	});
	
	/* Owl */
	
	if (jQuery(".slider-owl").length) {
		jQuery(".slider-owl").each(function () {
			var $slider = jQuery(this);
			var $slider_item = $slider.find('.slider-item').length;
			$slider.find('.slider-item').css({"height":"auto"});
			if ($slider.find('img').length) {
				var $slider = jQuery(this).imagesLoaded(function() {
					$slider.owlCarousel({
						autoplay: 3000,
						margin: 10,
						responsive: {
							0: {
								items: 1
							}
						},
						autoplayHoverPause: true,
						navText : ["", ""],
						nav: ($slider_item > 1)?true:false,
						rtl: is_RTL,
						loop: ($slider_item > 1)?true:false,
					});
				});
			}else {
				$slider.owlCarousel({
					autoplay: 3000,
					margin: 10,
					responsive: {
						0: {
							items: 1
						}
					},
					autoplayHoverPause: true,
					navText : ["", ""],
					nav: ($slider_item > 1)?true:false,
					rtl: is_RTL == true,
					loop: ($slider_item > 1)?true:false,
				});
			}
		});
	}
	
	/* Lightbox */
	
	var lightboxArgs = {			
		animation_speed: "fast",
		overlay_gallery: true,
		autoplay_slideshow: false,
		slideshow: 5000, // light_rounded / dark_rounded / light_square / dark_square / facebook
		theme: "pp_default", 
		opacity: 0.8,
		show_title: false,
		social_tools: "",
		deeplinking: false,
		allow_resize: true, // Resize the photos bigger than viewport. true/false
		counter_separator_label: "/", // The separator for the gallery counter 1 "of" 2
		default_width: 940,
		default_height: 529
	};
		
	jQuery("a[href$=jpg], a[href$=JPG], a[href$=jpeg], a[href$=JPEG], a[href$=png], a[href$=gif], a[href$=bmp]:has(img)").prettyPhoto(lightboxArgs);
			
	jQuery("a[class^='prettyPhoto'], a[rel^='prettyPhoto']").prettyPhoto(lightboxArgs);
	
	/* Close */
	
	jQuery(document).keyup(function(event) {
		if (event.which == '27') {
			
			/* Panel pop */
			
			jQuery.when(jQuery(".panel-pop").fadeOut(200)).done(function() {
				jQuery(this).css({"top":"-100%","display":"none"});
				jQuery(".wrap-pop").remove();
			});
			
			/* Mobile menu */
			
			jQuery('.mobile-aside').removeClass('mobile-aside-open');
			
			/* User login */
			
			jQuery(".user-login-click").removeClass("user-click-open").find(" > ul").slideUp(200);
			
			/* User notifications */
			
			jQuery(".user-login-area .user-notifications > div").slideUp(200);
			jQuery(".user-notifications-seen").removeClass("user-notifications-seen");
		}
	});
	
	/* Load */
	
	$window.load(function() {
		
		/* Loader */
		
		jQuery(".loader").fadeOut(500);
		
		/* matchHeight sidebar & content & Sticky */
		
		discy_sidebar();
		
		$window.bind("resize", function () {
			discy_sidebar();
		});
	});
	
})(jQuery);

function discy_sidebar() {
	var main_wrap_h = jQuery(".discy-main-wrap").outerHeight();
	var nav_menu_h  = jQuery(".nav_menu").outerHeight();
	if (jQuery('.menu_left').length && nav_menu_h > main_wrap_h) {
		jQuery('.discy-main-inner,.nav_menu').matchHeight();
	}else if (main_wrap_h > nav_menu_h && jQuery(".fixed_nav_menu").length) {
		jQuery('.discy-main-wrap,.fixed_nav_menu').theiaStickySidebar();
	}
}